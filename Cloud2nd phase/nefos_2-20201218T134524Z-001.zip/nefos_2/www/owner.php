<?php
   include('session.php');
   error_reporting(0);
   global $result;
   global $error;
   $role= $login_role['name'];
   //echo "<h1>$id</h1>";

  

   if ($role != 'Owner'){ //check if user is cinema owner
    header("Location: badAuth.php");
    exit();
   }
   $sql = "SELECT NAME FROM Cinemas WHERE OWNERID = '$id'";
   $result = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
   $active = $row['NAME'];
   //echo $active;

   $sql = "SELECT * FROM Movies WHERE CINEMANAME = '$active'";
   $result = mysqli_query($db,$sql);



   if($tmp = $_POST['add']){ //add movie 

    $title     = $_POST["title"];
    $start      = $_POST["start"];
    $end         = $_POST["end"];
    $category      = $_POST["category"];

    if (!empty($title) && !empty($start) && !empty($end) && !empty($category) ){ //all fields must be filled

      if($end >= $start){ //end date must be after start date

      
      $mysqlstart = date("Y-m-d H:i:s",strtotime($start));
      $mysqlend =date("Y-m-d H:i:s",strtotime($end));
    

    // echo $title;
    // echo $start;
    // echo $end;
    // echo $category;

    $sql2 = $db->query("INSERT INTO Movies (TITLE, STARTDATE, ENDDATE, CINEMANAME, CATEGORY) 
    VALUES ('$title', '$mysqlstart', '$mysqlend', '$active', '$category')");
    
    if(!$sql2){
        die("MySQL query failed!" . mysqli_error($db));
    } else {
        header("Refresh:0");
    }
    //header("Refresh:0");
    }else{
      $start="";
      $end="";
      $error="End date is before the Start date!";
    }
  }else{
    $error="Please fill all the cells!"  ;  
  }
  }
  if($tmp = $_POST['Update']){ // update cinema name
    $newname = $_POST['cinemaname'];
    if(!empty($newname)){
      $sql = "SELECT NAME FROM Cinemas WHERE NAME = '$newname'";
      $result = mysqli_query($db,$sql);
      $count = mysqli_num_rows($result);
      if ($count==0){    
        $sql2 = $db->query("UPDATE Cinemas SET NAME = '$newname' 
        WHERE OWNERID = (SELECT ID FROM Users WHERE USERNAME = '$login_session') ");
        $sql2 = $db->query("UPDATE Movies SET CINEMANAME = '$newname' 
        WHERE CINEMANAME = '$active' ");
        header("Refresh:0");
      }else{
        $message = 'Cinema name exists!' ;
        echo "<script type='text/javascript'>window.alert('$message');window.location.href='/owner.php';</script>";
      }
    }else{
      $message = 'Cinema name empty!' ;
      echo "<script type='text/javascript'>window.alert('$message');window.location.href='/owner.php';</script>";
    }

   } 


    if($id = $_POST['Delete']){ //delete movie
      $sql2 = $db->query("DELETE FROM Movies WHERE ID = '$id'");
      $sql2 = $db->query("DELETE FROM Favorites WHERE MOVIEID = '$id'");
      header("Refresh:0");
     } 

     if($id = $_POST['Submit']){ // change movie details
      $title     = $_POST["title"];
      $start      = $_POST["start"];
      $mysqlstart = date("Y-m-d H:i:s",strtotime($start));
      $end         = $_POST["end"];
      $mysqlend =date("Y-m-d H:i:s",strtotime($end));
      $category      = $_POST["category"];
      if (!empty($title) && !empty($start) && !empty($end) && !empty($category) ){
      if($end >= $start){
      $sql2 = $db->query("UPDATE Movies 
      SET
       TITLE = '$title',
       STARTDATE = '$mysqlstart',
       ENDDATE = '$mysqlend',
       CATEGORY = '$category'
       WHERE ID = '$id'");
      //echo "<div style='text-align: center;'><h4>$firstname $lastname $email $username $role  $id</h4></div>";
      header("Refresh:0");
    }else{
      $message = 'End date is before the Start date!' ;
      echo "<script type='text/javascript'>window.alert('$message');window.location.href='/owner.php';</script>";
    }
  }else{
    $message = 'All fields must be filled!' ;
    echo "<script type='text/javascript'>window.alert('$message');window.location.href='/owner.php';</script>";
  }
     } 



?>
<script type="text/javascript">
if ( window.history.replaceState ) {
  window.history.replaceState( null, null, window.location.href );
}
</script>
<html>
   
   <head>
      <title>Owner Page </title>
      <link rel="stylesheet" href="style.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <style>
  .addMovie{
    float:right;
    margin: 100px 50px;
    border-radius: 5px;
    background-color: #f2f2f2;
    padding: 2%;
    min width: 250px ;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,1);
  }
  .two{
    margin:100px 50px  ;
    float : left;
    width: 60%;
    min-width:785px;
   }
  .icon {  
  background: #4CAF50;;
  color: white;
  padding: 6px 5px;
  margin: 0;
  text-align: center;
  border-radius:10px;
}
.icon:hover {
  background-color: #45a049;
}
  div {
  white-space: normal;
}
.nametag{
  text-align:right;
  background-color: #4CAF50;;
  position:fixed; 
  right:20px; 
  top:0px;
  color: white;
  padding: 14px 20px;
  border: none;
  border-radius: 10px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,1);
}
</style>
   </head>

   
   <body style="background : #cdffb0">
   <h2 class="nametag"><?php echo $login_session; ?> <a href="logout.php"><i class="fa fa-sign-out icon"><b>Logout</b> </i></a></h2>
   
   <div class="dropdown">
  <button class="dropbtn"><i class = "fa fa-bars"></i> MENU</button>
  <div class="dropdown-content">
    <a href="welcome.php"><i class = "fa fa-home"></i> Home</a>
    <a href="movies.php"><i class = "fa fa-user"></i> User Portal</a>
    <a href="owner.php"><i class = "fa fa-table"></i> Owner Portal</a>
    <a href="admin.php"><i class = "fa fa-wrench"></i> Administrator Portal</a>
    <a href="logout.php"><i class = "fa fa-user-times"></i> LogOut</a>
  </div>
</div>

  <div class="addMovie">
  <form action="" method="post">
            <label>Title  :</label><input type = "text" required name = "title" class = "box" value = '<?php echo $title; ?>'><br /><br />
            <label>Starts at  :</label><input type = "date" required name = "start" class = "box" value = '<?php echo $start; ?>'><br/><br />
            <label>Ends at  :</label><input type = "date" required name = "end" class = "box"value = '<?php echo $end; ?>'><br /><br />
            <label>Category  :</label><input type = "text" required name = "category" class = "box" value = '<?php echo $category; ?>'><br/><br />
            <input type = "submit" class="btn" name = "add" value = "Add Movie" /><br />

  </form>
  <div style = "font-size:11px; color:#cc0000; margin-top:10px"><?php echo $error; ?></div>
</div>
<div style = "margin:50px 50px 50px 50px;"> 
        <div class="two" >    
        <table class = "greenTable" style="border:none; box-shadow: 0px 8px 16px 0px rgba(0,0,0,1);">
                <thead > <tr> <th> CINEMA NAME </th> </tr></thead>

                  <tbody>
                  <form action="" method="post"> 
                      <tr><td>
                      <input  type="text" name="cinemaname" required value='<?php echo $active?>'> 
                      </td><td>
                      <button class="btn"  type="submit" name="Update" value="tmp">Update</button>                       
                      </form>                   
                  </td></tr></tbody></table>
                <table class = "greenTable" style="border:none; margin-top:20px; box-shadow: 0px 8px 16px 0px rgba(0,0,0,1);">
                <thead > <tr> <th> Title </th> <th>Starts </th> <th>Ends</th> <th> Category</th> </tr></thead>
                <?php
                while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)) {
                  $title= $row['TITLE'];
                  $start = $row['STARTDATE'];
                  $end = $row['ENDDATE'];
                  $category = $row['CATEGORY'];
                  //echo "<tr><td>";
                  ?>

                  <tbody>
                  <form action="" method="post"> 
                      <tr><td>
                      <input  type="text" name="title" required value='<?php echo $title?>'> 
                      </td><td>
                      <input type="date" name="start" required value='<?php echo $start?>'> 
                      </td><td>
                      <input type="date" name="end" required value='<?php echo $end?>'> 
                      </td><td>
                      <input type="text" name="category" required value='<?php echo $category?>'> 
                      </td><td>                      
                      <?php  $data = $row['ID'];?>
                      </td><td>
                      <button class="btn"  type="submit" name="Submit" value='<?php echo $data?>'>Submit </button>   
                      </td><td>           
                      </form>
                      <?php $data = $row['ID'];?>                    
                  <form method="post"> 
                  </td><td>
                      <button class="btnD"  type="submit" name="Delete" value='<?php echo $data?>'>Delete </button> 
                  </form>                     
                  </td></tr><?php
                }

        echo "</tbody></table>";
                ?></div>
     

  
    
</div>
   </body>
   
</html>