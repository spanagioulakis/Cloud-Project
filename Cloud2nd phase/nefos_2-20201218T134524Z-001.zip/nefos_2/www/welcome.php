<?php
   include('session.php');
   
   $role= $login_role['name'];
   


?>
<html>
   
   <head>
      <title>Welcome </title>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="style.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

   </head>
   <style>
   body {
    background-image: url("images/welcom.jpg");
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-size: cover;
  }

.icon {
  
  background: #4CAF50;
  color: white;
  padding: 14px 5px;
  margin: 10px 10px;
  min-width: 60px;
  text-align: center;
  border-radius:10px;
}
.icon:hover {
  background-color: #45a049;
}
.input-container {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  float: right;
  margin-bottom: 10px;
}
</style>
   
   <body>
   <div style="text-align:right; width:100%;background-color: green;
    color: white;">
    
    <div class= "input-container"><h2><?php echo $login_session; ?> (<?php echo $role;?>)</h2>
    <a href="logout.php" > <i class="fa fa-sign-out icon"> <b>Logout</b> </i> </a></div>
    
    </div>
   <div class="dropdown">
  <button class="dropbtn"><i class = "fa fa-bars"></i> MENU</button>
  <div class="dropdown-content">
    <a href="movies.php"><i class = "fa fa-user"></i> User Portal</a>
    <a href="owner.php"><i class = "fa fa-table"></i> Owner Portal</a>
    <?php if ($login_role['name'] == 'Administartor'){
      echo   ' <a href="http://localhost:3005/idm/admins/list_users"><i class = "fa fa-wrench"></i> Administrator Portal</a>';
    }

    ?>
    <a href="logout.php"><i class = "fa fa-user-times"></i> LogOut</a>
  </div>
</div>


   </body>
   
</html>