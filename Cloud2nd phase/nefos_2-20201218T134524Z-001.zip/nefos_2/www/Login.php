<?php
   include("config.php");
   session_start();
   global $error;
   // Turn off all error reporting
    //error_reporting(0);
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $myusername = mysqli_real_escape_string($db,$_POST['username']);
      $mypassword = mysqli_real_escape_string($db,$_POST['password']); 
      
      $sql = "SELECT ID, CONFIRMED FROM Users WHERE USERNAME = '$myusername' and PASSWORD = '$mypassword'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['CONFIRMED'];

      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
      if($count == 1) { //username and password exists
          if($active == 1){ // confirmed = 1
         $_SESSION['login_user'] = $myusername;
         
         header("location: welcome.php");
          }else{ // confirmed = 0
            $error = "You are not yet accepted";

          }
      }else {
         $error = "Your Login Name or Password is invalid";
      }
   }
?>
<html>
   
   <head>
      <title>Login Page</title>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      
      <style >
/* Full-width input fields */
input[type=text], input[type=password] {
  width: 80%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;

  background: #e5ffe1;
  border-bottom-right-radius:10px;
  border-top-right-radius:10px;
}

/* Set a style for all buttons */
.btn {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  border-radius:10px;
}
.icon {
  
  background: #4CAF50;
  color: white;
  padding: 14px 1px;
  margin: 8px 0;
  min-width: 50px;
  text-align: center;
  border-bottom-left-radius:10px;
  border-top-left-radius:10px;

}
.input-container {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  width: 100%;
  margin-bottom: 15px;
}
      </style>
      
   </head>
   
   <body style="background : #cdffb0">
	
      <div align = "center">
      <div style="background-color: #f2f2f2;border: solid 2px; width:300px; border-radius:10px; margin:100px;box-shadow: 0px 8px 16px 0px rgba(0,0,0,1);">
      <div style = "background-color:#4CAF50; border-top-left-radius:8px;border-top-right-radius:8px;  color:#FFFFFF; padding:6px;"><b>Login</b></div>
         <div style = "border-bottom-left-radius:10px;border-bottom-right-radius:10px;" align= "left" >
            
				
            <div style = " margin:16px">
               
               <form action = "" method = "post" style = "border-radius=10px; margin:18px">
               <div class="input-container">
               <i class="fa fa-user icon"></i>
                  <input type = "text" name = "username" placeholder="Username" required></div>
               <div class="input-container">
               <i class="fa fa-key icon"></i>
                  <input type = "password" name = "password" placeholder="Password" required/></div>
                  <input class="btn" type = "submit" value = " Log in "/><br />
               </form>
               <div style = "text-align:center">Don't have an acount? &nbsp;&nbsp;<a href=register.php >Sign Up!<a><div>
               
               <div style = "font-size:11px; color:#cc0000; margin-top:10px"><?php echo $error; ?></div>
					
            </div>
				
         </div>
         </div>
			
      </div>

   </body>
</html>