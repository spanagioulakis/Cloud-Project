<?php
// Configuring the database connection!
$db =new mysqli('db', 'root', 'test', "CinemaWebApp");
?>