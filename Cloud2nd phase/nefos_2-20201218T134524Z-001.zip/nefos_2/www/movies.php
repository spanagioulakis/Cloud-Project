<?php
   include('session.php');
   error_reporting(0);
   global $result;
   global $error;
   $role= $login_role['name'];
    //sql for fetching movies in favorites for the user
   $sql = "SELECT ID FROM Users WHERE USERNAME = '$login_session'";
   $result = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
   $id = $row['ID'];
   //echo "<h1>$id</h1>";
   $sql = "SELECT MOVIEID FROM Favorites WHERE USERID = '$id'";
   $result2 = mysqli_query($db,$sql);
   if ($result2->num_rows > 0) {
    // output data of each row
    $i=0;
    while($row = $result2->fetch_assoc()) {
      $id_m[$i] = $row['MOVIEID'];
      //echo "<h1 style='text-align:center'> $id_m </h1>";
      $i = $i+1;
    }
  }

   //$row2 = mysqli_fetch_array($result2);
   //$id_m = $row2[1];

  // aplly the search filters for html, in the beginning empty
   $filtert = $_POST["stitle"];
   $filtercin = $_POST["scinema"];
   $filtercat =$_POST["scat"];
   $filterdate = $_POST["date"];
   if ($filterdate == null){
       $filterdate = "NOW()";
       $sql = "SELECT * FROM Movies m WHERE TITLE LIKE '%$filtert%' AND CINEMANAME LIKE '%$filtercin%' AND CATEGORY LIKE '%$filtercat%'
        AND ($filterdate between m.STARTDATE AND m.ENDDATE)";
        $result = mysqli_query($db,$sql); 
   }else{
   $sql = "SELECT * FROM Movies m WHERE TITLE LIKE '%$filtert%' AND CINEMANAME LIKE '%$filtercin%' AND CATEGORY LIKE '%$filtercat%'
   AND ('$filterdate' between m.STARTDATE AND m.ENDDATE)";
   $result = mysqli_query($db,$sql); 
   }

   if($id2 = $_POST['favorite']){
    $sql2 = $db->query("INSERT INTO Favorites (USERID, MOVIEID) VALUES ('$id' , '$id2') ");
    header("Refresh:0");
   } 

   if($id2 = $_POST['removefav']){
    $sql2 = $db->query("DELETE FROM Favorites WHERE MOVIEID = '$id2' AND USERID = '$id' ");
    header("Refresh:0");
   } 


?>
<script type="text/javascript">
if ( window.history.replaceState ) {
  window.history.replaceState( null, null, window.location.href );
}
</script>
<html>
   
   <head>
      <title>Movies Page </title>
      <link rel="stylesheet" href="style.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>
   body {
    background-image: url("images/welcom.jpg");
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-size: cover;
  }
.icon {
  
  background: #4CAF50;
  color: white;
  padding: 14px 5px;
  margin: 10px 10px;
  min-width: 50px;
  text-align: center;
  border-radius:10px;

}
.icon:hover {
  background-color: #45a049;
}
.input-container {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  float: right;
  margin-bottom: 10px;
}

  table.greenTable {
    border: none;
    border-top-left-radius:0px;
    border-top-right-radius:0px;
  }
  table.topTable {
    border: none;
    border-bottom-left-radius:0px;
    border-bottom-right-radius:0px;
  }


  
</style>
   </head>

   
   <body>
   <div style="text-align:right; width:100%;background-color: green;right:0px; top:0px;
    color: white;">
    
    <div class= "input-container"><h2><?php echo $login_session; ?> (<?php echo $role; ?>)</h2>
    <a href="logout.php" ><i class="fa fa-sign-out icon"> <b>Logout</b> </i></a></div>
    
    </div>
 
<div class="dropdown">
  <button class="dropbtn"><i class = "fa fa-bars"></i> MENU</button>
  <div class="dropdown-content">
    <a href="welcome.php"><i class = "fa fa-home"></i> Home</a>
    <a href="favorite.php"><i class = "fa fa-star"></i> Favorites</a>
    <a href="owner.php"><i class = "fa fa-table"></i> Owner Portal</a>
    <a href="admin.php"><i class = "fa fa-wrench"></i> Administrator Portal</a>
    <a href="logout.php"><i class = "fa fa-user-times"></i> LogOut</a>
  </div>
</div>

<div style = "margin:100px 100px 100px 100px;">

<table class = "topTable" style="box-shadow: 0px 8px 16px 0px rgba(10,10,10,1); border:none;">
                  

                  <tbody>
                  <form action="" method="post"> 
                      <tr><td>
                      <input type="text" placeholder="Search..title" name = "stitle"> 
                      </td><td>
                      <input type="text" placeholder="Search..cinema" name = "scinema"> 
                      </td><td>
                      <input type="text" placeholder="Search..category" name = "scat"> 
                      </td><td>
                      <button class="btn"  type="submit" name="searchbtn" >Search</button> 
                  </form>  
                  </td><td>
                    <h2>   or.. </h2> 
                    
                    <form action="" method="post"> 
                    </td><td>
                    <input type="date" name="date"> 
                      </td><td>
                      <button class="btn"  type="submit" name="datebtn" value='<?php echo $data?>'>Search date </button>  
                      </form>                
                  </td></tr></tbody></table>
     

  
 
        <div >    
                <table class = "greenTable"style="  box-shadow: 0px 8px 16px 0px rgba(10,10,10,1); border:none;"><?php
                echo "<thead> <tr> <th>Title </th> <th>Starts </th> <th>Ends</th> <th> Category</th> <th> Cinema</th> </tr></thead>";

                while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)) { //while to show all the movies one by one
                  $title= $row['TITLE'];
                  $start = $row['STARTDATE'];
                  $end = $row['ENDDATE'];
                  $category = $row['CATEGORY'];
                  $cinemaname = $row['CINEMANAME'];
                  $movieid = $row['ID'];
                  //echo count($id_m);
                  foreach ($id_m as $r ) { //check if movie is in favorites in order to display the right button
                    $id_mo = $r;
                    if ($id_mo == $movieid){
                      $tag=1;
                      }
              }

                  //echo "<tr><td>";
                  ?>

                  <tbody>
                  <form action="" method=""> 
                      <tr><td>
                      <input type="text" name="title" readonly="readonly" value='<?php echo $title?>'> 
                      </td><td>
                      <input type="date" name="start" readonly="readonly" value='<?php echo $start?>'> 
                      </td><td>
                      <input type="date" name="end" readonly="readonly" value='<?php echo $end?>'> 
                      </td><td>
                      <input type="text" name="category" readonly="readonly" value='<?php echo $category?>'> 
                      </td><td>
                      <input type="text" name="cinemaname" readonly="readonly" value='<?php echo $cinemaname?>'>
                      </td><td>
                </form>

                      <?php
                      if ($tag ==1 ){ // is in favorites button -> remove
                      $data = $row['ID'];
                      ?>                    
                  <form method="post"> 
                  </td><td>
                      <button class="btnD"  type="submit" name="removefav" value=<?php echo $data?>>Remove form favorites </button> 
                  </form>                     
                  </td></tr><?php
                  }else{ // is NOT in favorites button -> add
                    $data = $row['ID'];?>                    
                    <form method="post"> 
                    </td><td>
                        
                        <button class="btnC"  type="submit" name="favorite" value=<?php echo $data?>>Add to favourites </button> 
                    </form>                     
                    </td></tr><?php
                  } $tag=0; 
                }

        echo "</tbody></table>"
                ?></div>
     

  
    
</div>
   </body>
   
</html>