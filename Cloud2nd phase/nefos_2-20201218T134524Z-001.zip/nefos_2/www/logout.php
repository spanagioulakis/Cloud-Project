<?php
   session_start();
   //destroy session 
   $clientId = 'a72e24aa-dcd7-4d73-a2b6-5e25e6f17001';
   if(session_destroy()) {
      header('Location: http://localhost:3005/auth/external_logout?_method=DELETE&client_id='.$clientId.'&redirect_uri=http://localhost:8001/index.php' );
   }
?>