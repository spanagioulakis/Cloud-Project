<?php
   include('session.php');
    global $resultl;
    error_reporting(0);
    
   $sql = "SELECT ROLE FROM Users WHERE USERNAME = '$login_session'";
   $result = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
   $active = $row['ROLE'];
   if ($active != 'ADMIN'){ //check if user is admin
    header("Location: badAuth.php");
    exit();
   }
   $sql = "SELECT * FROM Users";
   $result = mysqli_query($db,$sql);

   if($id = $_POST['Confirm']){ //Confirm user
   $sql2 = $db->query("UPDATE Users SET CONFIRMED = 1 WHERE ID = '$id'");
   header("Refresh:0");
   }
   if($id = $_POST['Delete']){ //delete user
     $role = $_POST["role"];
    if ($role == "CINEMAOWNER"){//delete his cinema if cinema owner and the movies on this cinema
      $sql2 = $db->query("DELETE FROM Movies WHERE CINEMANAME = (SELECT NAME FROM Cinemas WHERE OWNERID ='$id')");
      $sql = $db->query("DELETE FROM Cinemas  WHERE OWNERID = '$id' ");   

   }
    $sql2 = $db->query("DELETE FROM Users WHERE ID = '$id'");
    header("Refresh:0");
   } 
   if($id = $_POST['Submit']){ //change user 
    $firstname     = $_POST["name"];
    $lastname      = $_POST["surname"];
    $email         = $_POST["email"];
    $username      = $_POST["username"];
    $passcode      = $_POST["password"];
    $role          = $_POST["role"];
    $sql2 = $db->query("UPDATE Users 
    SET
     NAME = '$firstname',
     SURNAME = '$lastname',
     USERNAME = '$username',
     EMAIL = '$email', 
     PASSWORD = '$passcode', 
     ROLE = '$role'
     WHERE ID = '$id'");
     if ($role == "CINEMAOWNER"){
      $sql3 = "SELECT ID FROM Cinemas WHERE OWNERID=$id";
      $result3 = mysqli_query($db,$sql3);
      //$d = mysqli_fetch_array($result3,MYSQLI_ASSOC);
      $count = mysqli_num_rows($result3);
      if ($count == 0 ){ //add cinema if user changed to cinema owner
        $sql = $db->query("INSERT INTO Cinemas (OWNERID, NAME) 
        VALUES ((SELECT ID FROM Users WHERE USERNAME = '$username' ) ,'$username')");
        }

      }
      else{ //change from cinema owner to other role, deletes movies and cinema
        $sql2 = $db->query("DELETE FROM Movies WHERE CINEMANAME = (SELECT NAME FROM Cinemas WHERE OWNERID ='$id')");
        $sql = $db->query("DELETE FROM Cinemas  WHERE OWNERID = '$id' ");        
      }
    //echo "<div style='text-align: center;'><h4>$firstname $lastname $email $username $role  $id</h4></div>";
    header("Refresh:0");
   } 
?>
<html">
   
  <head>
      <title>Administartor Page </title>
      <link rel="stylesheet" href="style.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <style>
  body {
    background-image: url("images/admin.jpg");
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-size: cover;
  }
  .icon {  
  background: #4CAF50;
  color: white;
  padding: 6px 5px;
  margin: 0;
  text-align: center;
  border-radius:10px;
  }
  .icon:hover {
    background-color: #45a049;
  }
  .nametag{
    text-align:right;
    background-color: #4CAF50;
    position:fixed;
    right:20px; top:0px;
    color: white;
    padding: 14px 20px;
    border: none;
    border-radius: 10px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,1);
  } 
   input[type=email]{
    min-width: 75px;
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      background: #e5ffe1;
      border: 1px solid #ccc;
      border-radius: 10px;
      box-sizing: border-box;
    }
  </style>
  </head>

   
   <body>
     <div>
   <h2 class="nametag" ><?php echo $login_session; ?> <a href="logout.php"><i class="fa fa-sign-out icon"> <b>Logout</b> </i></a></h2>
    


  <div class="dropdown">
  <button class="dropbtn"><i class = "fa fa-bars"></i> MENU</button>
  <div class="dropdown-content">
    <a href="welcome.php"><i class = "fa fa-home"></i> Home</a>
    <a href="movies.php"><i class = "fa fa-user"></i> User Portal</a>
    <a href="owner.php"><i class = "fa fa-table"></i> Owner Portal</a>
    <a href="admin.php"><i class = "fa fa-wrench"></i> Administrator Portal</a>
    <a href="logout.php"><i class = "fa fa-user-times"></i> LogOut</a>
  </div>
</div>


  </div>
     

       <div style = "margin:100px 200px 200px 200px;">    
                <table class = "greenTable" style="  box-shadow: 8px 16px 32px 8px rgba(0,0,0,1); border:none;"><?php
                echo "<thead> <tr> <th>Name </th> <th>Surname </th> <th>Username</th> <th> E-mail</th> <th> Password</th> <th> Role</th> </tr></thead>";

                while($row = mysqli_fetch_array($result,MYSQLI_ASSOC)) { // displaying the database data one by on in loop 
                  $name= $row['NAME'];
                  $surname = $row['SURNAME'];
                  $user = $row['USERNAME'];
                  $mail = $row['EMAIL'];
                  $role = $row['ROLE'];
                  $pass = $row['PASSWORD'];
                  //echo "<tr><td>";
                  ?>

                  <tbody>
                  <form action="" method="post"> 
                      <tr><td>
                      <input type="text" name="name" value='<?php echo $name?>' required> 
                      </td><td>
                      <input type="text" name="surname" value='<?php echo $surname?>' required> 
                      </td><td>
                      <input type="text" name="username" value='<?php echo $user?>' required> 
                      </td><td>
                      <input type = "email" name = "email" placeholder="E-mail" required value = <?php echo $mail; ?> ></div> 
                      </td><td>
                      <input type="text" name="password" value='<?php echo $pass?>' required> 
                      </td><td>
                      <label for="role"></label>
                            <select name="role" id="role">
                            <option value=<?php echo $role?> selected><?php echo $role?></option>
                            <option value="USER">User</option>
                            <option value="CINEMAOWNER">Cinema Owner</option>
                            <option value="ADMIN">Administartor</option>
                            </select>
                      
                      <?php
                   $data = $row['ID'];?>
                      </td><td>
                      <button class="btn"  type="submit" name="Submit" value=<?php echo $data?>>Submit </button> 
                      </td><td>
                      <?php 
                      if ( $row['CONFIRMED'] == 1){
                        echo "<div class='txt'>CONFRIRMED!</div>";
                    }else{
                        $data = $row['ID'];?>
                                              
                          <button class="btnC" type="submit" name="Confirm" value=<?php echo $data?>>Confirm </button> 
                      
                        <?php };
                      
                  
                  $data = $row['ID'];?>
                    
                  
                  </td><td>
                      <button class="btnD"  type="submit" name="Delete" value=<?php echo $data?>><i class ="fa fa-trash"></i></button> 
                  </form>                     
                  </td></tr><?php
                }

                echo "</tbody></table>"
                ?></div>
  
    

   </body>
   
</html>