<?php
session_start();
$state = hash('sha256', session_id());
/**
 * Replace the values below with your integration's information found on the marketplace build page.
 * https://marketplace.teamleader.eu/eu/en/build/integrations
 */
$clientId = 'a72e24aa-dcd7-4d73-a2b6-5e25e6f17001';
$clientSecret = 'f92a12c0-e8cd-42c5-a944-445ea746926a';

/**
 * Where to redirect to after the OAuth 2 flow was completed.
 * Make sure this matches the information of your integration settings on the marketplace build page.
 */
$redirectUri = 'http://localhost:8001/oauth.php';

/* ------------------------------------------------------------------------------------------------- */

/**
 * When the OAuth2 authentication flow was completed, the user is redirected back with a code.
 * If we received the code, we can get an access token and make API calls. Otherwise we redirect
 * the user to the OAuth2 authorization endpoints.
 */
if (!empty($_GET['code'])) {

    $code = rawurldecode($_GET['code']);
 

    // /**
    //  * Request an access token based on the received authorization code.
    //  */
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'keyrock:3005/oauth2/token');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
    curl_setopt($ch, CURLOPT_TIMEOUT, 0);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
    $body = array (
        'code' => $code,
        'client_id' => $clientId,
        'client_secret' => $clientSecret,
        'redirect_uri' => $redirectUri,
        'grant_type' => 'authorization_code'
        );
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($body));
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Content-Type: application/x-www-form-urlencoded'));
    
    $response = curl_exec($ch);
    if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
    echo"\n";
    }
    curl_close($ch);
    $data = json_decode($response, true);
    $accessToken = $data['access_token'];
    $refreshToken = $data['refresh_token'];

    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, 'http://keyrock:3005/user?access_token='.$accessToken);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

    $result = curl_exec($ch);
    if (curl_errno($ch)) {
        echo 'Error:' . curl_error($ch);
    }
    curl_close($ch);
    $user_data = json_decode($result, true);
    if (isset($user_data['username'])){
        $_SESSION['login_user'] = $user_data['username'];
        $role = $user_data['roles'][0];
        echo "\n";
        echo $role['name'];
        $_SESSION['type'] = $user_data['roles'][0];
        $_SESSION['id'] = $user_data['id'];
        $_SESSION['accessToken'] = $accessToken;
        $_SESSION['refresh'] = $refreshToken;
        echo '<script>window.location="welcome.php"</script>';
        die();
    }


} else {

    $query = [
        'client_id' => $clientId,
        'response_type' => 'code',
        'redirect_uri' => $redirectUri,
    ];

    header('Location: http://localhost:3005/oauth2/authorize?client_id=a72e24aa-dcd7-4d73-a2b6-5e25e6f17001&response_type=code&state='.$state.'&redirect_uri=http://localhost:8001/oauth.php' );

}