<?php
   include('session.php');
   error_reporting(0);

    
   $sql = "SELECT ROLE,ID FROM Users WHERE USERNAME = '$login_session'";
   $result = mysqli_query($db,$sql);
   $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
   $id = $row['ID'];
   $active = $row['ROLE'];
   $sql = "SELECT m.TITLE, f.ID FROM Movies m, Favorites f WHERE f.USERID = '$id' AND m.ID = f.MOVIEID"; //select all favorites for current user
   $result2 = mysqli_query($db,$sql);
   if ($active == "ADMIN"){
    $role= "Administrator";
 }else if ($active == "USER"){
    $role= "User";
 }else if ($active == "CINEMAOWNER"){
    $role= "Cinema Owner";
 }



   if($id2 = $_POST['removefav']){ // delete entry from favorites
    $sql2 = $db->query("DELETE FROM Favorites WHERE ID = '$id2' ");
    header("Refresh:0");
   } 


?>
<script type="text/javascript">
if ( window.history.replaceState ) {
  window.history.replaceState( null, null, window.location.href );
}
</script>
<html>
   
   <head>
      <title>Favorites Page </title>
      <link rel="stylesheet" href="style.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

      <style>              
       body {
    background-image: url("images/welcom.jpg");
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-size: cover;
  }
  table.greenTable {
  border: none;
}
.div1{
    background-image: url("images/stars.gif");
    color: white;
    padding: 14px 20px;
    border: none;
    border-radius: 10px;

}

.icon {
  
  background: #4CAF50;
  color: white;
  padding: 14px 5px;
  margin: 10px 10px;
  min-width: 50px;
  text-align: center;
  border-radius:10px;

}
.icon:hover {
  background-color: #45a049;
}
.input-container {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  float: right;
  margin-bottom: 10px;
}  
</style>
   </head>

   
   <body>
   <div style="text-align:right; width:100%;background-color: green;right:0px; top:0px;
    color: white;">
    
    <div class= "input-container"><h2><?php echo $login_session; ?> (<?php echo $role; ?>)</h2>
    <a href="logout.php" ><i class="fa fa-sign-out icon"> <b>Logout</b> </i></a></div>
    
    </div>
    <div class="dropdown">
  <button class="dropbtn"><i class = "fa fa-bars"></i> MENU</button>
  <div class="dropdown-content">
    <a href="welcome.php"><i class = "fa fa-home"></i> Home</a>
    <a href="movies.php"><i class = "fa fa-user"></i> User Portal</a>
    <a href="owner.php"><i class = "fa fa-table"></i> Owner Portal</a>
    <a href="admin.php"><i class = "fa fa-wrench"></i> Administrator Portal</a>
    <a href="logout.php"><i class = "fa fa-user-times"></i> LogOut</a>
  </div>
</div>


<div class = "div1"> <h1 style="text-align:center" > Favorites </h1></div>

<div style = "margin:100px 100px 100px 100px;">

 
        <div >    
                <table class = "greenTable" style="box-shadow: 0px 8px 16px 0px rgba(10,10,10,1); border:none;"><?php
                echo "<thead> <tr> <th>Title </th> </tr></thead>";

                while($row = mysqli_fetch_array($result2,MYSQLI_ASSOC)) { //loop to display one by one the favorite movies
                  $title= $row['TITLE'];
                  $data = $row['ID'];
                  ?>

                  <tbody>
                  <form action="" method=""> 
                      <tr><td>
                      <input type="text" name="title" readonly="readonly" value='<?php echo $title?>'>    
                </form>        
                </td><td>               
                    <form action="" method="post"> 
                    </td><td>
                        <button class="btnD"  type="submit" name="removefav" value=<?php echo $data?>>Remove form favorites </button> 
                    </form>                     
                    </td></tr><?php
                  
                }

        echo "</tbody></table>"
                ?></div>
     

  
    
</div>
   </body>
   
</html>