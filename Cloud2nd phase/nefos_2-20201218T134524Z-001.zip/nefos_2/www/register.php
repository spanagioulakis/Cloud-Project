<?php
   include("config.php");
   error_reporting(0);
   global $error;
   global $success_msg;
   
   
   
   
   if($_SERVER["REQUEST_METHOD"] == "POST") { //register user
      // data sent from form 

      $firstname     = $_POST["name"];
      $lastname      = $_POST["surname"];
      $email         = $_POST["email"];
      $username      = $_POST["username"];
      $passcode      = $_POST["password"];
      $passcodec     = $_POST["passwordc"];
      $role          = $_POST["role"]; 
      $cinemaname    = $_POST["cinemaname"]; 
      // verify if username exists
      $userCheck = $db->query( "SELECT * FROM Users WHERE USERNAME = '{$username}' ");
      //$count = mysqli_num_rows($result);
      $count = mysqli_num_rows($userCheck);
      if($count==0){
      // verify if email exists
      $emailCheck = $db->query( "SELECT * FROM Users WHERE EMAIL = '{$email}' ");
      //$count = mysqli_num_rows($result);
      $rowCount = mysqli_num_rows($emailCheck);
      if($rowCount == 0){
        if(!empty($firstname) && !empty($lastname) && !empty($email) && !empty($username) && !empty($passcode)){
         if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            if ($passcode == $passcodec){
               if ($role != "CINEMAOWNER"){ //dont care about cinema name
           
            $sql = $db->query("INSERT INTO Users (NAME, SURNAME, USERNAME, PASSWORD, EMAIL, ROLE) 
            VALUES ('$firstname', '$lastname', '$username', '$passcode', '$email', '$role')");

            if(!$sql){
                die("MySQL query failed!" . mysqli_error($db));
            } else {
                $success_msg = 'User registered successfully!';
            echo "<script type='text/javascript'>window.alert('$success_msg'); window.location.href='/index.php';</script>";
            // header("Location: Login.php");
            // exit();

            }
         }else{

            if(!empty($cinemaname)){ //check if cinema is filled
              $sql = "SELECT NAME FROM Cinemas WHERE NAME = '$cinemaname'";
              $result = mysqli_query($db,$sql);
              $count = mysqli_num_rows($result);
              if ($count==0){ //check if cinema name taken
               $sql = $db->query("INSERT INTO Users (NAME, SURNAME, USERNAME, PASSWORD, EMAIL, ROLE) 
               VALUES ('$firstname', '$lastname', '$username', '$passcode', '$email', '$role')");
               if($sql){ 
                  $sql = $db->query("INSERT INTO Cinemas (OWNERID, NAME) 
                  VALUES ((SELECT ID FROM Users WHERE USERNAME = '$username' ) ,'$cinemaname')");
               }

               if(!$sql){
                   die("MySQL query failed!" . mysqli_error($db));
               } else {
                   $success_msg = 'User registered successfully!';
               echo "<script type='text/javascript'>window.alert('$success_msg'); window.location.href='/index.php';</script>"; //alert in javascript and redirect to login page
               // header("Location: Login.php");
               // exit();
               
               }
              }else{
               $error = 'Cinema name exists!' ;
            }
         }else{
            $error = 'Cinema name empty!' ;
         }

         }

         }else{
            $error = "Passwords don't match!";
         }
         }else{
            $error = "Invalid email format!";
         }

        }else{
            $error = "Please fill all the fields!";
        }
        
      }else{
         $email="";
        $error = "Email exists!";
      }
   }else{
      $username="";
      $error = "username already taken!";
   }
    }
   
      
?>
<html>
   
   <head>
      <title>SignUp Page</title>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      
      <style >
      
/* Full-width input fields */
input[type=text],input[type=email], input[type=password], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
  border-bottom-right-radius:10px;
  border-top-right-radius:10px;
  background: #e5ffe1;
}

/* Set a style for all buttons */
.btn {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  border-radius:10px;
}
.icon {
  
  background: #4CAF50;
  color: white;
  padding: 14px 1px;
  margin: 8px 0;
  min-width: 50px;
  text-align: center;
  border-bottom-left-radius:10px;
  border-top-left-radius:10px;

}
.input-container {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  width: 100%;
  margin-bottom: 15px;
}
.box {
   display: -ms-flexbox; /* IE10 */
  display: flex;
  width: 100%;
  margin-bottom: 15px;
}
      </style>
      <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script>
$(document).ready(function(){
    $("select").change(function(){
        $(this).find("option:selected").each(function(){
            var optionValue = $(this).attr("value");
            if(optionValue == "CINEMAOWNER"){
               
                $(".box").show();
            } else{
                $(".box").hide();
            }
        });
    }).change();
});
</script>
      
   </head>
   
   <body style="background : #cdffb0">
	
      <div align = "center">
      <div style="background-color: #f2f2f2;border: solid 3px; width:500px; border-radius:10px; margin:50px;box-shadow: 0px 8px 16px 0px rgba(0,0,0,1);">
      <div style = "background-color:#4CAF50; border-top-left-radius:8px;border-top-right-radius:8px;  color:#FFFFFF; padding:6px;"><b>Register</b></div>
         <div style = "border-bottom-left-radius:10px;border-bottom-right-radius:10px;" align= "left" >
            
				
            <div style = "border-radius=10px; margin:30px">
               
               <form action = "" method = "post">
                    <!--<label>Name  :</label>-->
                    <div class="input-container">
                    <i class="fa fa-ellipsis-h icon"></i>
                    <input type = "text" name = "name" placeholder="Name" required value = <?php echo $firstname; ?> ></div>
                    <!--<label>Surname  :</label>-->
                    <div class="input-container">
                    <i class="fa fa-ellipsis-h icon"></i>
                    <input type = "text" name = "surname" placeholder="Surname" required value = <?php echo $lastname; ?> ></div>
                    <!--<label>Email  :</label>-->
                    <div class="input-container">
                    <i class="fa fa-envelope icon"></i>
                    <input type = "email" name = "email" placeholder="E-mail" required value = <?php echo $email; ?> ></div>
                    <!--<label>UserName  :</label>-->
                    <div class="input-container">
                    <i class="fa fa-user icon"></i>
                    <input type = "text" name = "username" placeholder="Username" required value = <?php echo $username; ?> ></div>
                    <!--<label>Password  :</label>-->
                    <div class="input-container">
                    <i class="fa fa-key icon"></i>
                    <input type = "password" name = "password" placeholder="Password" required /></div>
                    <!--<label>Confirm Password  :</label>-->
                    <div class="input-container">
                    <i class="fa fa-key icon"></i>
                    <input type = "password" name = "passwordc" placeholder="Confirm Password" required /></div>
                        <!--<label for="role">Choose a role:</label>-->
                    <div class="input-container">
                    <i class="fa fa-users icon"></i>
                            <select name="role" id="role"required>
                            <option value="USER">User</option>
                            <option value="CINEMAOWNER">Cinema Owner</option>
                            <option value="ADMIN">Administartor</option>
                            </select>
                            </div>
                     <!--<label>Confirm Password  :</label>-->
                    <div class="box">
                    <i class="fa fa-institution icon"></i>
                    <input type = "text" name = "cinemaname" placeholder="Cinema Name" /></div>


                  <input class="btn" type = "submit" value = " Register "/><br />
               </form>               
               <div style = "font-size:11px; color:#cc0000; margin-top:10px"><?php echo $error; ?></div>
               <div style = "text-align:right;"><?php echo $success_msg; ?><a href=Login.php >Go to Log In Page<a></div>
					
            </div>
				
         </div>
			
      </div>

   </body>
</html>