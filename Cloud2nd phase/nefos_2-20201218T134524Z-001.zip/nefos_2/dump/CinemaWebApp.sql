-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 07, 2020 at 01:24 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
-- START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `CinemaWebApp`
--

-- --------------------------------------------------------

--
-- Table structure for table `Cinemas`
--

CREATE TABLE `Cinemas` (
  `ID` int(11) NOT NULL,
  `OWNERID` int(11) NOT NULL,
  `NAME` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Cinemas`
--

INSERT INTO `Cinemas` (`ID`, `OWNERID`, `NAME`) VALUES
(1, 7, 'Cinema2'),
(2, 14, 'Test cinema'),
(26, 9, 'Cinemax at Rethymno'),
(27, 18, 'johncinema1'),
(33, 27, 'Cineland');

-- --------------------------------------------------------

--
-- Table structure for table `Favorites`
--

CREATE TABLE `Favorites` (
  `ID` int(11) NOT NULL,
  `USERID` int(11) NOT NULL,
  `MOVIEID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Favorites`
--

INSERT INTO `Favorites` (`ID`, `USERID`, `MOVIEID`) VALUES
(6, 7, 3),
(8, 1, 3),
(14, 7, 5),
(15, 14, 5);

-- --------------------------------------------------------

--
-- Table structure for table `Movies`
--

CREATE TABLE `Movies` (
  `ID` int(11) NOT NULL,
  `TITLE` varchar(300) NOT NULL,
  `STARTDATE` date NOT NULL,
  `ENDDATE` date NOT NULL,
  `CINEMANAME` varchar(200) NOT NULL,
  `CATEGORY` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Movies`
--

INSERT INTO `Movies` (`ID`, `TITLE`, `STARTDATE`, `ENDDATE`, `CINEMANAME`, `CATEGORY`) VALUES
(3, 'movie1', '2020-10-01', '2020-11-30', 'Cinema2', 'Horror'),
(5, 'movie test screen', '2020-10-27', '2020-11-20', 'Test cinema', 'Horror');

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

CREATE TABLE `Users` (
  `ID` int(11) NOT NULL,
  `NAME` varchar(50) NOT NULL,
  `SURNAME` varchar(50) NOT NULL,
  `USERNAME` varchar(20) NOT NULL,
  `PASSWORD` varchar(30) NOT NULL,
  `EMAIL` varchar(100) NOT NULL,
  `ROLE` enum('ADMIN','CINEMAOWNER','USER') NOT NULL,
  `CONFIRMED` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`ID`, `NAME`, `SURNAME`, `USERNAME`, `PASSWORD`, `EMAIL`, `ROLE`, `CONFIRMED`) VALUES
(1, 'Yiannis', 'Moschakis', 'admin', 'admin', 'johnmosx@hotmail.com', 'ADMIN', 1),
(7, 'Ioannis', 'Moschakis', 'imoschakis', '070798', 'mjohnmosxakis@gmail.com', 'CINEMAOWNER', 1),
(9, 'test', 'testsurname', 'tester', '123456', 'testmail@test.com', 'CINEMAOWNER', 1),
(10, 'John moschakis', 'sdf', 'adfs', 'adfs', 'mjohnmosxsdfvakis@gmail.com', 'USER', 0),
(14, 'testuser', 'testuser', 'tester1', '123456', 'test@test2.com', 'CINEMAOWNER', 1),
(16, 'Ioannis', 'Moschakis', 'testuser', '123456', 'testmail@testmail.com', 'USER', 0),
(18, 'john', 'mosx', 'imosx', '123456', 'john@mosx.com', 'CINEMAOWNER', 0),
(27, 'Ioannis', 'Moschakis', 'tuc', '123456', 'j@j.n', 'CINEMAOWNER', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Cinemas`
--
ALTER TABLE `Cinemas`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `NAME` (`NAME`);

--
-- Indexes for table `Favorites`
--
ALTER TABLE `Favorites`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `Movies`
--
ALTER TABLE `Movies`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `Users`
--
ALTER TABLE `Users`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `USERNAME` (`USERNAME`),
  ADD UNIQUE KEY `EMAIL` (`EMAIL`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Cinemas`
--
ALTER TABLE `Cinemas`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `Favorites`
--
ALTER TABLE `Favorites`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `Movies`
--
ALTER TABLE `Movies`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `Users`
--
ALTER TABLE `Users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
